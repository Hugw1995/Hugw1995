---
title: Introduction to the Basic JavaScript RPG Game
block: Basic JavaScript RPG Game
superBlock: JavaScript Algorithms and Data Structures
isBeta: true
---
## Introduction to the Basic JavaScript RPG Game

This is a test for the new project-based curriculum.
