export default {
  event: () => {}
};
