import ReactGA from 'react-ga';

ReactGA.initialize('UA-55446531-10');

export default ReactGA;
