## Test scripts for the boot directory

These files cannot be co-located with the files under test due to the auto-discovery the loopback-boot employs.
