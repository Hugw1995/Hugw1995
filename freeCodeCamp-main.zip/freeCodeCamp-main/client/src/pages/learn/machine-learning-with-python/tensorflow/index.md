---
title: Introduction to the TensorFlow Lectures
block: TensorFlow
superBlock: Machine Learning with Python
---
## Introduction to the TensorFlow Challenges

TensorFlow is an open source framework developed by the Google Brain team aimed to make the powers of machine learning and neural networking easier to use.

The following lectures were created by Tim Ruscica, otherwise known as “Tech With Tim” from his educational programming YouTube channel. They will help you to understand TensorFlow and some of its capabilities.