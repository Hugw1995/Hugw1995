import createRedirect from './createRedirect';
import { withPrefix } from 'gatsby';

export default createRedirect(withPrefix('/'));
