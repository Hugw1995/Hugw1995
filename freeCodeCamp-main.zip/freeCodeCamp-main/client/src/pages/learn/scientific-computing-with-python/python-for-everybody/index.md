---
title: Introduction to Python for Everybody
block: Python for Everybody
superBlock: Scientific Computing with Python
---
## Introduction to Python for Everybody

Python for Everybody is a video course that teaches the basics of programming computers using Python 3.

The course was created by Dr. Charles Severance (a.k.a. Dr. Chuck). He is a Clinical Professor at the University of Michigan School of Information, where he teaches various technology-oriented courses including programming, database design, and Web development.


