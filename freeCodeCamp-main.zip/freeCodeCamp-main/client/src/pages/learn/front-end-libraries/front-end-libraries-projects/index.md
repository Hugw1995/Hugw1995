---
title: Introduction to the Front End Libraries Projects
block: Front End Libraries Projects
superBlock: Front End Libraries
---
## Introduction to the Front End Libraries Projects

It's now time to test out the frontend skills learned. This will help to bolster your skills, so don't hesitate to showcase your frontend skills in these projects.
In this section you will complete the following projects with Bootstrap, jQuery, Sass, React and Redux:
* A Random Quote Machine
* A Markdown Previewer
* A Drum Machine
* A JavaScript Calculator
* A 25 + 5 Clock

Have fun and remember to use the [Read-Search-Ask](https://forum.freecodecamp.org/t/how-to-get-help-when-you-are-stuck-coding/19514) method if you get stuck.
