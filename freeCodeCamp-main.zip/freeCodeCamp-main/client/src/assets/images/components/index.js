import AppleLogo from './AppleLogo.js';
import AmazonLogo from './AmazonLogo.js';
import MicrosoftLogo from './MicrosoftLogo.js';
import SpotifyLogo from './SpotifyLogo.js';
import GoogleLogo from './GoogleLogo.js';
import AsFeatureLogo from './AsFeatureLogo.js';

export {
  AmazonLogo,
  AppleLogo,
  MicrosoftLogo,
  SpotifyLogo,
  GoogleLogo,
  AsFeatureLogo
};
