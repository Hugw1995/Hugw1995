---
title: Introduction to the JavaScript Algorithms and Data Structures Projects
block: JavaScript Algorithms and Data Structures Projects
superBlock: JavaScript Algorithms and Data Structures
---
## Introduction to the JavaScript Algorithms and Data Structures Projects

Time to put your new JavaScript skills to work! These challenges will be similar to the algorithm scripting challenges but more difficult. This will allow you to prove how much you have learned.

In this section you will create the following small JavaScript programs:
 * Palindrome Checker
 * Roman Numeral Converter
 * Caesars Cipher
 * Telephone Number Validator
 * Cash Register

Have fun and remember to use the [Read-Search-Ask](https://forum.freecodecamp.org/t/how-to-get-help-when-you-are-stuck-coding/19514) method if you get stuck.

Good Luck!
