/* eslint-disable camelcase */
/* This is used for testing. If a motivation.json file doesn't match the
 * structure here exactly, the tests will fail.
 */
const motivationSchema = {
  compliments: ['yes'],
  motivationalQuotes: ['woohoo']
};

exports.motivationSchema = motivationSchema;
