---
title: Introduction to the CSS Grid Challenges
block: CSS Grid
superBlock: Responsive Web Design
---
## Introduction to the CSS Grid Challenges

<dfn>CSS Grid</dfn> helps you easily build complex web designs. It works by turning an HTML element into a grid container with rows and columns for you to place children elements where you want within the grid.

