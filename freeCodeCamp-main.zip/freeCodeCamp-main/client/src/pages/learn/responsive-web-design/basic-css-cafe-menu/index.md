---
title: Introduction to the Basic CSS Cafe Menu
block: Basic CSS Cafe Menu
superBlock: Responsive Web Design
isBeta: true
---
## Introduction to the Basic CSS Cafe Menu

This is a test for the new project-based curriculum.